import java.util.HashMap;
import java.util.Map;

public class DuplicateCharacters {

    public static void main(String[] args) {
        String str = "hello world";
        Map<Character, Integer> duplicateChars = findDuplicateCharacters(str);
        
        System.out.println("Duplicate characters in the string \"" + str + "\":");
        for (Map.Entry<Character, Integer> entry : duplicateChars.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue() + " occurrences");
        }
    }

    public static Map<Character, Integer> findDuplicateCharacters(String str) {
        Map<Character, Integer> charCountMap = new HashMap<>();
        Map<Character, Integer> duplicateChars = new HashMap<>();

       
        for (char ch : str.toCharArray()) {
            charCountMap.put(ch, charCountMap.getOrDefault(ch, 0) + 1);
        }

        
        for (Map.Entry<Character, Integer> entry : charCountMap.entrySet()) {
            if (entry.getValue() > 1) {
                duplicateChars.put(entry.getKey(), entry.getValue());
            }
        }

        return duplicateChars;
    }
}