public class MergeArrays {

    
    public static void mergeArrays(int[] X, int m, int[] Y, int n) {
        int i = n - 1; 
        int j = 0;     
        int k = 0;    

        
        for (int p = 0; p < m; p++) {
            if (X[p] != 0) {
                X[i] = X[p];
                i--;
            }
        }

        
        i = n; 
        while (i < m && j < n) {
            if (X[i] < Y[j]) {
                X[k++] = X[i++];
            } else {
                X[k++] = Y[j++];
            }
        }

       
        while (j < n) {
            X[k++] = Y[j++];
        }
    }

   
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] X = {0, 2, 0, 3, 0, 5, 6, 0, 0};
        int[] Y = {1, 8, 9, 10, 15};

        int m = X.length;
        int n = Y.length;

        mergeArrays(X, m, Y, n);

        System.out.print("Merged array: ");
        printArray(X);
    }
}